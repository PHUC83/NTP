﻿#include "framework.h"


float pos[2];
float size3[2];
float color1[4];
float rotationX;
float rotationY;
float rotationZ;


enum stencil_states
{
	BothOn,
	BothOff,
	TestOnWriteOff,
	TestOffWriteOn
};

framework::framework(HWND hwnd) : hwnd(hwnd)
{
}

bool framework::initialize()
{
	//①デバイス・デバイスコンテキスト・スワップチェーンの作成 
	HRESULT hr(S_OK);

	UINT create_device_flags{ 0 };
#ifdef _DEBUG
	create_device_flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	D3D_FEATURE_LEVEL feature_levels{ D3D_FEATURE_LEVEL_11_0 };

	DXGI_SWAP_CHAIN_DESC swap_chain_desc{};
	swap_chain_desc.BufferCount = 1;
	swap_chain_desc.BufferDesc.Width = SCREEN_WIDTH;
	swap_chain_desc.BufferDesc.Height = SCREEN_HEIGHT;
	swap_chain_desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	swap_chain_desc.BufferDesc.RefreshRate.Numerator = 60;
	swap_chain_desc.BufferDesc.RefreshRate.Denominator = 1;
	swap_chain_desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swap_chain_desc.OutputWindow = hwnd;
	swap_chain_desc.SampleDesc.Count = 1;
	swap_chain_desc.SampleDesc.Quality = 0;
	swap_chain_desc.Windowed = !FULLSCREEN;
	hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, create_device_flags,
		&feature_levels, 1, D3D11_SDK_VERSION, &swap_chain_desc,
		swap_chain.GetAddressOf(), device.GetAddressOf(), NULL, immediate_context.GetAddressOf());
	_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));


	//レンダーターゲットビューの作成
	ID3D11Texture2D* back_buffer{};
	hr = swap_chain.Get()->GetBuffer(0, __uuidof(ID3D11Texture2D),
		reinterpret_cast<LPVOID*>(&back_buffer));
	_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

	hr = device.Get()-> CreateRenderTargetView(back_buffer, NULL, &render_target_view);

	_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
	back_buffer->Release();


	//深度ステンシルビューの作成
	ID3D11Texture2D * depth_stencil_buffer{};
	D3D11_TEXTURE2D_DESC texture2d_desc{};
	texture2d_desc.Width = SCREEN_WIDTH;
	texture2d_desc.Height = SCREEN_HEIGHT;
	texture2d_desc.MipLevels = 1;
	texture2d_desc.ArraySize = 1;
	texture2d_desc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	texture2d_desc.SampleDesc.Count = 1;
	texture2d_desc.SampleDesc.Quality = 0;
    texture2d_desc.Usage = D3D11_USAGE_DEFAULT;
    texture2d_desc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    texture2d_desc.CPUAccessFlags = 0;
    texture2d_desc.MiscFlags = 0;
    hr = device.Get()->CreateTexture2D(&texture2d_desc, NULL,
		&depth_stencil_buffer);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
   
    D3D11_DEPTH_STENCIL_VIEW_DESC depth_stencil_view_desc{};
    depth_stencil_view_desc.Format = texture2d_desc.Format;
    depth_stencil_view_desc.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
    depth_stencil_view_desc.Texture2D.MipSlice = 0;
    hr = device.Get()->CreateDepthStencilView(depth_stencil_buffer, &depth_stencil_view_desc, &depth_stencil_view);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
   
    depth_stencil_buffer->Release();

	//ビューポートの設定
    D3D11_VIEWPORT viewport{};
    viewport.TopLeftX = 0;
    viewport.TopLeftY = 0;
    viewport.Width = static_cast<float>(SCREEN_WIDTH);
    viewport.Height = static_cast<float>(SCREEN_HEIGHT);
    viewport.MinDepth = 0.0f;
    viewport.MaxDepth = 1.0f;
    immediate_context->RSSetViewports(1, &viewport);


	{
		//② framework クラスのinitialize メンバ関数でサンプラーステートオブジェクトを生成する
		D3D11_SAMPLER_DESC sampler_desc;
		sampler_desc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
		sampler_desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
		sampler_desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
		sampler_desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
		sampler_desc.MipLODBias = 0;
		sampler_desc.MaxAnisotropy = 16;
		sampler_desc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
		sampler_desc.BorderColor[0] = 0;
		sampler_desc.BorderColor[1] = 0;
		sampler_desc.BorderColor[2] = 0;
		sampler_desc.BorderColor[3] = 0;
		sampler_desc.MinLOD = 0;
		sampler_desc.MaxLOD = D3D11_FLOAT32_MAX;
		hr = device.Get()->CreateSamplerState(&sampler_desc, &sampler_states[0]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		sampler_desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
		hr = device.Get()->CreateSamplerState(&sampler_desc, &sampler_states[1]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		sampler_desc.Filter = D3D11_FILTER_ANISOTROPIC;
		hr = device.Get()->CreateSamplerState(&sampler_desc, &sampler_states[2]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
	}

	{
	//②framework クラスのinitialize メンバ関数で深度ステンシルステートオブジェクトを作成する
		{
			D3D11_DEPTH_STENCIL_DESC depth_stencil_desc{};
			depth_stencil_desc.DepthEnable = TRUE;
			depth_stencil_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
			depth_stencil_desc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
			hr = device.Get()->CreateDepthStencilState(&depth_stencil_desc, &depth_stencil_states[BothOn]);
			_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));



			depth_stencil_desc.DepthEnable = FALSE;
			depth_stencil_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
			hr = device.Get()->CreateDepthStencilState(&depth_stencil_desc, &depth_stencil_states[BothOff]);
			_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));




			depth_stencil_desc.DepthEnable = TRUE;
			depth_stencil_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
			hr = device.Get()->CreateDepthStencilState(&depth_stencil_desc, &depth_stencil_states[TestOnWriteOff]);
			_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));



			depth_stencil_desc.DepthEnable = FALSE;
			depth_stencil_desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
			hr = device.Get()->CreateDepthStencilState(&depth_stencil_desc, &depth_stencil_states[TestOffWriteOn]);
			_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
		}
	}
	{
		D3D11_BLEND_DESC blend_desc{};
		blend_desc.AlphaToCoverageEnable = FALSE;
		blend_desc.IndependentBlendEnable = FALSE;
		blend_desc.RenderTarget[0].BlendEnable = TRUE;
		blend_desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
		blend_desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
		blend_desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		blend_desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
		blend_desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
		hr = device.Get()->CreateBlendState(&blend_desc, &blend_states[0]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		//無効
		blend_desc.RenderTarget[0].BlendEnable = FALSE;
		hr = device.Get()->CreateBlendState(&blend_desc, &blend_states[1]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		//加算
		blend_desc.RenderTarget[0].BlendEnable = TRUE;
		blend_desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
		blend_desc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
		blend_desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		blend_desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
		blend_desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
		hr = device.Get()->CreateBlendState(&blend_desc, &blend_states[2]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		//減算
		blend_desc.RenderTarget[0].BlendEnable = TRUE;
		blend_desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
		blend_desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
		blend_desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		blend_desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
		blend_desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
		hr = device.Get()->CreateBlendState(&blend_desc, &blend_states[3]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

		//乗算
		blend_desc.RenderTarget[0].BlendEnable = TRUE;
		blend_desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		blend_desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
		blend_desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
		blend_desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
		blend_desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
		blend_desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
		hr = device.Get()->CreateBlendState(&blend_desc, &blend_states[4]);
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

	}
	{
		//シーン定数バッファオブジェクトを生成する
		D3D11_BUFFER_DESC buffer_desc{};
		buffer_desc.ByteWidth = sizeof(scene_constants);
		buffer_desc.Usage = D3D11_USAGE_DEFAULT;
		buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		buffer_desc.CPUAccessFlags = 0;
		buffer_desc.MiscFlags = 0;
		buffer_desc.StructureByteStride = 0;
		hr = device->CreateBuffer(&buffer_desc, nullptr, constant_buffers[0].GetAddressOf());
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
	}

	{
		D3D11_RASTERIZER_DESC rasterizer_desc{};
		rasterizer_desc.FillMode = D3D11_FILL_SOLID;
		rasterizer_desc.CullMode = D3D11_CULL_BACK;
		rasterizer_desc.FrontCounterClockwise = TRUE;
		/*rasterizer_desc.FrontCounterClockwise = FALSE;*/
		rasterizer_desc.DepthBias = 0;
		rasterizer_desc.DepthBiasClamp = 0;
		rasterizer_desc.SlopeScaledDepthBias = 0;
		rasterizer_desc.DepthClipEnable = TRUE;
		rasterizer_desc.ScissorEnable = FALSE;
		rasterizer_desc.MultisampleEnable = FALSE;
		rasterizer_desc.AntialiasedLineEnable = FALSE;
		hr = device->CreateRasterizerState(&rasterizer_desc, rasterizer_states[0].GetAddressOf());
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
		
		rasterizer_desc.FillMode = D3D11_FILL_WIREFRAME;
		rasterizer_desc.CullMode = D3D11_CULL_BACK;

		rasterizer_desc.AntialiasedLineEnable = TRUE;
	
		hr = device->CreateRasterizerState(&rasterizer_desc, rasterizer_states[1].GetAddressOf());
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
		
		rasterizer_desc.FillMode = D3D11_FILL_WIREFRAME;
		rasterizer_desc.CullMode = D3D11_CULL_NONE;
		rasterizer_desc.AntialiasedLineEnable = TRUE;
		hr = device->CreateRasterizerState(&rasterizer_desc, rasterizer_states[2].GetAddressOf());
		_ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
	}


	/*sprites[0] = new sprite(device.Get(), L"./resources/cyberpunk.jpg");
	sprites[1] = new sprite(device.Get(), L"./resources/player.png");
	sprite_batches[0] = new sprite_batch(device.Get(), L"./resources/player.png", 2048);*/
	//geometric_primitives[0] = std::make_unique<cube>(device.Get());
	/*geometric_primitives[1] = std::make_unique<cylinder>(device.Get());*/
	//geometric_primitives[2] = std::make_unique<sphere>(device.Get());
	/*static_meshes[1] = std::make_unique<static_mesh>(device.Get(), L".\\resources\\cube.obj");*/
	//static_meshes[1] = std::make_unique<static_mesh>(device.Get(), L".\\resources\\Cup\\cup.obj");
	//static_meshes[1] = std::make_unique<static_mesh>(device.Get(), L".\\resources\\Rock\\Rock.obj");
	//skinned_meshes[0] = std::make_unique<skinned_mesh>(device.Get(), ".\\resources\\cube.000.fbx");
	//skinned_meshes[0] = std::make_unique<skinned_mesh>(device.Get(), ".\\resources\\cube.003.1.fbx", true);
	skinned_meshes[0] = std::make_unique<skinned_mesh>(device.Get(), ".\\resources\\cube.004.fbx", true);
	pos[0] = 0;
	pos[1] = 0;
	size3[0] = 1280;
	size3[1] = 720;
	color1[0] = 1;
	color1[1] = 0;
	color1[2] = 1;
	color1[3] = 1;
	rotationX = 0.0f;
	rotationY = 0.0f;
	rotationZ = 0.0f;
	return true;
}

void framework::update(float elapsed_time/*Elapsed seconds from last frame*/)
{
#ifdef USE_IMGUI
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
#endif


#ifdef USE_IMGUI
	ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_Once);
	ImGui::SetNextWindowSize(ImVec2(300, 300), ImGuiCond_Once);
	//if (ImGui::Begin("ImGUI"));
	if (ImGui::Begin("ImGUI", nullptr, ImGuiWindowFlags_None))
	{
		if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen))
		{
			//ImGui::InputFloat2("Position", pos);
			ImGui::SliderFloat("PositionX", &pos[0], 0, SCREEN_WIDTH);
			ImGui::SliderFloat("PositionY", &pos[1], 0, SCREEN_HEIGHT);
			ImGui::DragFloat("SizeX", &size3[0]);
			ImGui::DragFloat("SizeY", &size3[1]);
			//ImGui::InputFloat2("Size", size);
			ImGui::SliderFloat("Rotation X", &rotationX, -DirectX::XM_PI, DirectX::XM_PI);
			ImGui::SliderFloat("Rotation Y", &rotationY, -DirectX::XM_PI, DirectX::XM_PI);
			ImGui::SliderFloat("Rotation Z", &rotationZ, -DirectX::XM_PI, DirectX::XM_PI);
		}

		ImGui::ColorEdit4("Color", color1);
	}


	ImGui::End();
#endif
}
void framework::render(float elapsed_time/*Elapsed seconds from last frame*/)
{
	HRESULT hr{ S_OK };

	FLOAT color[]{ 0, 0, 0.2f, 1.0f };
	immediate_context->ClearRenderTargetView(render_target_view, color);
	immediate_context->ClearDepthStencilView(depth_stencil_view,
		D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);
	immediate_context->OMSetRenderTargets(1, &render_target_view, depth_stencil_view);

	immediate_context->PSSetSamplers(0, 1, &sampler_states[0]);
	immediate_context->PSSetSamplers(1, 1, &sampler_states[1]);
	immediate_context->PSSetSamplers(2, 1, &sampler_states[2]);
	immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOff], 1);
	immediate_context->OMSetBlendState(blend_states[0], nullptr, 0xFFFFFFFF);
	immediate_context->RSSetState(rasterizer_states[0].Get());

	//ビュー・プロジェクション変換行列を計算し、それを定数バッファにセットする
	D3D11_VIEWPORT viewport;
	UINT num_viewports{ 1 };
	immediate_context->RSGetViewports(&num_viewports, &viewport);

	float aspect_ratio{ viewport.Width / viewport.Height };
	XMMATRIX P{ XMMatrixPerspectiveFovLH(XMConvertToRadians(30), aspect_ratio, 0.1f, 100.0f) };
	XMVECTOR eye{ XMVectorSet(0.0f, 0.0f, -10.0f, 1.0f) };
	XMVECTOR focus{ XMVectorSet(0.0f, 0.0f, 0.0f, 1.0f) };
	XMVECTOR up{ XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f) };
	XMMATRIX V{ XMMatrixLookAtLH(eye, focus, up) };
	/*DirectX::XMVECTOR light_direction = DirectX::XMVectorSet(-1.0, -1.0f, 0.0f, 0.0f); */
	scene_constants data{};
	XMStoreFloat4x4(&data.view_projection, V * P);
	//data.light_direction = { 0, 0, 1, 0 };

	data.light_direction = {0,0,1,0};
	data.camera_position = {0,0,-10,1.0f};


	immediate_context->UpdateSubresource(constant_buffers[0].Get(), 0, 0, &data, 0, 0);
	immediate_context->VSSetConstantBuffers(1, 1, constant_buffers[0].GetAddressOf());
	immediate_context->PSSetConstantBuffers(1, 1, constant_buffers[0].GetAddressOf());
	////DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
	////DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(0, 0, 0) };
	////DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0, 0, 0) };

	//DirectX::XMFLOAT4X4 world;
	//DirectX::XMStoreFloat4x4(&world, S * R * T);
	//sprites[0]->render(immediate_context, 200,300,100,100,0,1,0,1,70);
	//sprites[0]->render(immediate_context, pos[0], pos[1],size[0], size[1], color1[0], color1[1], color1[2], color1[3],0,0,0,0,0);
	//sprites[0]->render(immediate_context.Get(), 0, 0, 1280, 720, 1, 1, 1, 1, 0);
	//sprites[1]->render(immediate_context, 500, 200, 200, 200, color1[0], color1[1], color1[2], color1[3], 0, 0, 0, 140, 240);
	float x{ 0 };
	float y{ 0 };
#if 0
	for (size_t i = 0; i < 1092; ++i)
	{
		sprites[1]->render(immediate_context,
			x, static_cast<float>(static_cast<int>(y) % 720), 64, 64,
			1, 1, 1, 1, 0, 140 * 0, 240 * 0, 140, 240);
		x += 32;
		if (x > 1280 - 64)
		{
			x = 0;
			y += 24;
		}
	}
#else
	/*sprite_batches[0]->begin(immediate_context.Get());
	for (size_t i = 0; i < 1092; ++i)
	{
		sprite_batches[0]->render(immediate_context.Get(),
			x, static_cast<float>(static_cast<int>(y) % 720), 64, 64,
			1, 1, 1, 1, 0, 140 * 0, 240 * 0, 140, 240);
		x += 32;
		if (x > 1280 - 64)
		{
			x = 0;
			y += 24;
		}
	}
	sprite_batches[0]->end(immediate_context.Get());*/

	//DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
	//DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
	//DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0, 0, 0) };

	//DirectX::XMMATRIX worldMatrix = S * R * T;
	//DirectX::XMFLOAT4X4 world;
	//DirectX::XMStoreFloat4x4(&world, worldMatrix);
	//immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
	//immediate_context->RSSetState(rasterizer_states[0].Get());

	/*geometric_primitives[2]->render(immediate_context.Get(), world, { color1[0], color1[0], color1[2], color1[3] });*/


	//{
	//	DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
	//	DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
	//	DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(2,0,0) };

	//	DirectX::XMMATRIX worldMatrix = S * R * T;
	//	DirectX::XMFLOAT4X4 world;
	//	DirectX::XMStoreFloat4x4(&world, worldMatrix);
	//	immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
	//	immediate_context->RSSetState(rasterizer_states[0].Get());

	//	geometric_primitives[0]->render(immediate_context.Get(), world, { color1[0], color1[0], color1[2], color1[3] });
	//}

	/*{
		DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
		DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
		DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0,0,0) };

		DirectX::XMMATRIX worldMatrix = S * R * T;
		DirectX::XMFLOAT4X4 world;
		DirectX::XMStoreFloat4x4(&world, worldMatrix);
		immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
		immediate_context->RSSetState(rasterizer_states[0].Get());

		geometric_primitives[1]->render(immediate_context.Get(), world, { color1[0], color1[0], color1[2], color1[3] });
	}*/

	//{
	//	DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
	//	DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
	//	DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0,0,0) };

	//	DirectX::XMMATRIX worldMatrix = S * R * T;
	//	DirectX::XMFLOAT4X4 world;
	//	DirectX::XMStoreFloat4x4(&world, worldMatrix);
	//	immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
	//	immediate_context->RSSetState(rasterizer_states[0].Get());

	//	//static_meshes[1]->render(immediate_context.Get(), world, { 1, 1, 1, 1.0f });
	
	
		/*{
			DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
			DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
			DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0,0,0) };

			DirectX::XMMATRIX worldMatrix = S * R * T;
			DirectX::XMFLOAT4X4 world;
			DirectX::XMStoreFloat4x4(&world, worldMatrix);
			immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
			immediate_context->RSSetState(rasterizer_states[0].Get());

			skinned_meshes[0]->render(immediate_context.Get(), world, { 1, 1, 1, 1 });
		
		}*/
		{
			const DirectX::XMFLOAT4X4 coordinate_system_transforms[]{
	{ -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }, // RHS Y-UP
	{ 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }, // LHS Y-UP
	{ -1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1 }, // RHS Z-UP
	{ 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1 }, // LHS Z-UP
			};

			// To change the units from centimeters to meters, set 'scale_factor' to 0.01.
			const float scale_factor = 1.0f;

			DirectX::XMMATRIX C{ DirectX::XMLoadFloat4x4(&coordinate_system_transforms[3]) *
								 DirectX::XMMatrixScaling(scale_factor, scale_factor, scale_factor) };

			DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
			DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
			DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0, 0, 0) };

			DirectX::XMFLOAT4X4 world;
			DirectX::XMStoreFloat4x4(&world, C * S * R * T);
			immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
			immediate_context->RSSetState(rasterizer_states[0].Get());
			skinned_meshes[0]->render(immediate_context.Get(), world, { 1, 1, 1, 1 });
		}
	/*{
		DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
		DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
		DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(0, 0, 0) };

		DirectX::XMMATRIX worldMatrix = S * R * T;
		DirectX::XMFLOAT4X4 world;
		DirectX::XMStoreFloat4x4(&world, worldMatrix);

		immediate_context->RSSetState(rasterizer_states[1].Get());
		static_meshes[1]->render_bounding_box(
			immediate_context.Get(),
			world,
			{ 1, 1, 1, 1 }  
		);
	}*/
//	{	DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
//	DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
//	DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(1, 1, 1) };
//
//	DirectX::XMMATRIX worldMatrix = S * R * T;
//	DirectX::XMFLOAT4X4 world;
//	DirectX::XMStoreFloat4x4(&world, worldMatrix);
//	immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
//	immediate_context->RSSetState(rasterizer_states[0].Get());
//
//	static_meshes[0]->render(immediate_context.Get(), world, { 0.5f, 0.8f, 0.2f, 1.0f });
////}
//		DirectX::XMMATRIX S{ DirectX::XMMatrixScaling(1, 1, 1) };
//		DirectX::XMMATRIX R{ DirectX::XMMatrixRotationRollPitchYaw(rotationX, rotationY, rotationZ) };
//		DirectX::XMMATRIX T{ DirectX::XMMatrixTranslation(1, 1, 1) };
//
//		DirectX::XMMATRIX worldMatrix = S * R * T;
//		DirectX::XMFLOAT4X4 world;
//		DirectX::XMStoreFloat4x4(&world, worldMatrix);
//		immediate_context->OMSetDepthStencilState(depth_stencil_states[BothOn], 1);
//		immediate_context->RSSetState(rasterizer_states[0].Get());
//	static_meshes[1]->render(immediate_context.Get(),world, { 0.5f, 0.8f, 0.2f, 1.0f });

#endif

#ifdef USE_IMGUI
	ImGui::Render();
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
#endif

	UINT sync_interval{ 0 };
	swap_chain.Get()->Present(sync_interval, 0);

}

bool framework::uninitialize()
{
	release_all_textures();
	for (ID3D11BlendState* p : blend_states)
	{
		if (p)
		{
			p->Release();
			p = nullptr;
		}

	}

	for (ID3D11DepthStencilState* p : depth_stencil_states)
	{
		if (p)
		{
			p->Release();
			p = nullptr;
		}

	}

	for (ID3D11SamplerState* p : sampler_states)
	{
		if (p)
		{
			p->Release();
			p = nullptr;
		}

	}

	for (sprite* p : sprites)
	{
		if (p)
		{
			delete p;
			p = nullptr;

		}
	}
	for (sprite_batch* p : sprite_batches)
	{
		if (p)
		{
			delete p;
			p = nullptr;

		}
	}

    //swap_chain->Release();
    depth_stencil_view->Release();
    render_target_view->Release();
    //immediate_context->Release();
    //device->Release();

	return true;
}

framework::~framework()
{

}